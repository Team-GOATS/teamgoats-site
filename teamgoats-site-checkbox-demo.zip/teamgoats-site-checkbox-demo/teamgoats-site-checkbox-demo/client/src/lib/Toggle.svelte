<script>
  import { onMount } from "svelte";
  const STORAGE_KEY = "theme";
  const DARK_PREFERENCE = "(prefers-color-scheme: dark)";

  const THEMES = {
    DARK: "dark",
    LIGHT: "light",
  };

  const prefersDarkThemes = () => window.matchMedia(DARK_PREFERENCE).matches;

  let currentTheme;
  const applyTheme = () => {
    const preferredTheme = prefersDarkThemes() ? THEMES.DARK : THEMES.LIGHT;
    currentTheme = localStorage.getItem(STORAGE_KEY) ?? preferredTheme;

    currentTheme = localStorage.getItem(STORAGE_KEY) ?? preferredTheme;

    if (currentTheme === THEMES.DARK) {
      document.body.classList.remove(THEMES.LIGHT);
      document.body.classList.add(THEMES.DARK);
    } else {
      document.body.classList.remove(THEMES.DARK);
      document.body.classList.add(THEMES.LIGHT);
    }
  };

  const toggleTheme = () => {
    const stored = localStorage.getItem(STORAGE_KEY);

    if (stored) {
      localStorage.removeItem(STORAGE_KEY);
    } else {
      localStorage.setItem(
        STORAGE_KEY,
        prefersDarkThemes() ? THEMES.LIGHT : THEMES.DARK
      );
    }
    applyTheme();
  };

  onMount(() => {
    applyTheme();
    window.matchMedia(DARK_PREFERENCE).addEventListener("change", applyTheme);
  });
</script>

<label class="themeToggle" title="Toggle Theme">
  <input
    type="checkbox"
    checked={currentTheme !== THEMES.LIGHT}
    on:click={toggleTheme}
  />
  <div class="animation">
    <span />
  </div>

  <!-- <span class="theme-toggle-sr">Toggle theme</span> -->
</label>

<style>
  .themeToggle input {
    visibility: hidden;
    display: block;
    height: 0;
    width: 0;
    position: absolute;
    overflow: hidden;
  }

  label span {
    height: 30px;
    width: 30px;
    content: url("../assets/sun.svg");
  }

  [type="checkbox"]:checked ~ .animation,
  [type="checkbox"] ~ .animation {
    transition: all 250ms cubic-bezier(0.4, 0, 0.23, 1);
  }

  [type="checkbox"]:checked + .animation span {
    content: url("../assets/moon.svg");
  }
</style>
