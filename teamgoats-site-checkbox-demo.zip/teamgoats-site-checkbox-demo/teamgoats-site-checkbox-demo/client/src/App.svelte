<script>
  import Toggle from "./lib/Toggle.svelte";
</script>

<main>
  <Toggle />
  <h1>Svelte Toggle Switches</h1>
  <h2>Coming Soon</h2>
  <p>
    To keep updated on latest developments, check out our <a
      href="https://github.com/Team-GOATS"
      target="_blank"
      rel="noreferrer">GitHub</a
    >
  </p>
</main>

<style>
  main {
    text-align: center;
    margin: 10rem auto;
  }
  h2 {
    color: #0284c7;
  }
  p {
    margin: 4rem auto;
  }
  a {
    text-decoration: none;
    transition: all 0.6s ease-in-out;
  }
  a:hover {
    color: #0284c7;
  }


</style>
