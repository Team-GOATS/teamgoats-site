# Team GOATS Svelte Toggle Switches Site


This is the source code of the [Svelte Toggle Switches](https://sveltetoggles.onrender.com/) documentation.
